const native=globalThis.fetch;const orders=new Map();let seq=1;
globalThis.fetch=async function(uri,opts={}){const u=String(uri);if(!u.startsWith('https://api-m.sandbox.paypal.com/'))return native(uri,opts);
 const endpoint=u.replace('https://api-m.sandbox.paypal.com','');
 const respond=(o,status=200)=>new Response(JSON.stringify(o),{status,headers:{'Content-Type':'application/json'}});
 if(endpoint==='/v1/oauth2/token')return respond({access_token:'MOCK',expires_in:3600});
 if(endpoint==='/v2/checkout/orders'&&opts.method==='POST'){const obj=JSON.parse(opts.body);const id='MOCK-'+(seq++);orders.set(id,{id,status:'CREATED',purchase_units:obj.purchase_units});return respond({id,status:'CREATED'});}
 const m=endpoint.match(/^\/v2\/checkout\/orders\/(MOCK-\d+)(\/capture)?$/);if(m){const obj=orders.get(m[1]);if(!obj)return respond({message:'missing'},404);if(m[2]){obj.status='COMPLETED';obj.purchase_units[0].payments={captures:[{id:'CAP-'+m[1],status:'COMPLETED',amount:obj.purchase_units[0].amount}]};}return respond(obj);}
 return respond({error:'missing mock'},404);
};
