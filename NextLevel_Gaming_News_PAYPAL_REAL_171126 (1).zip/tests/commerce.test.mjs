import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(fileURLToPath(new URL('../',import.meta.url))),dir=mkdtempSync(path.join(tmpdir(),'nlg-commerce-')),port=31379;
const child=spawn(process.execPath,['server.mjs'],{cwd:root,env:{...process.env,PORT:String(port),NLG_PERSISTENT_DIR:dir,PAYPAL_CLIENT_ID:'MOCK',PAYPAL_CLIENT_SECRET:'MOCK',PAYPAL_ENV:'sandbox',NLG_COMMERCE_ENABLED:'YES',NODE_OPTIONS:'--import='+path.join(root,'tests/mock-paypal.mjs')},stdio:'ignore'});
const url=`http://127.0.0.1:${port}/api/store/`;
async function request(route,method='GET',body,token=''){const res=await fetch(url+route,{method,headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:body===undefined?undefined:JSON.stringify(body)});return {status:res.status,data:await res.json()};}
try{
 let ready=false;for(let i=0;i<70;i++){try{ready=(await request('status')).status===200;if(ready)break}catch{}await new Promise(r=>setTimeout(r,100));}assert.ok(ready,'server start');
 assert.equal((await request('status')).data.paymentsEnabled,true);
 const created=await request('account','POST',{});assert.equal(created.status,201);const code=created.data.recoveryCode;
 const data=(await import('../catalog.json',{with:{type:'json'}})).default;
 const ids=data.frames.filter(x=>x.rarity!=='godlike').slice(0,6).map(x=>x.id);
 assert.equal((await request('orders','POST',{kind:'bundle',choices:ids.slice(0,4)},code)).status,400);
 assert.equal((await request('orders','POST',{kind:'bundle',choices:Array(5).fill(ids[0])},code)).status,400);
 const order=await request('orders','POST',{kind:'bundle',choices:ids.slice(0,5),price:1},code);assert.equal(order.status,201);assert.equal(order.data.total,'2.00');
 const pending=await request('orders/'+order.data.orderId+'/reconcile','POST',{},code);assert.equal(pending.status,200);assert.equal(pending.data.receipt.status,'pending');
 const paid=await request('orders/'+order.data.orderId+'/capture','POST',{},code);assert.equal(paid.status,200);assert.equal(paid.data.entitlements.frames.length,5);
 const reconciled=await request('orders/'+order.data.orderId+'/reconcile','POST',{},code);assert.equal(reconciled.data.receipt.status,'completed');
 const repeated=await request('orders/'+order.data.orderId+'/capture','POST',{},code);assert.equal(repeated.status,200);assert.equal(repeated.data.entitlements.frames.length,5);
 assert.ok((await request('orders','POST',{kind:'bundle',choices:ids.slice(0,5)},code)).status>=400);
 const godlikeId=data.frames.find(x=>x.rarity==='godlike')?.id;assert.ok(godlikeId,'GODLIKE available');
 const godlike=await request('orders','POST',{kind:'frameGodlike',choices:[godlikeId]},code);assert.equal(godlike.status,201);assert.equal(godlike.data.total,'3.00');
 const glPaid=await request('orders/'+godlike.data.orderId+'/capture','POST',{},code);assert.equal(glPaid.status,200);assert.ok(glPaid.data.entitlements.frames.includes(godlikeId));
 const bgId=data.backgrounds.find(x=>x.rarity!=='godlike').id;
 const bg=await request('orders','POST',{kind:'background',choices:[bgId]},code);assert.equal(bg.status,201);
 const bgPaid=await request('orders/'+bg.data.orderId+'/capture','POST',{},code);assert.deepEqual(bgPaid.data.entitlements.backgrounds,[bgId]);
 const prem=await request('orders','POST',{kind:'premium',choices:[]},code);assert.equal(prem.status,201);
 const premPaid=await request('orders/'+prem.data.orderId+'/capture','POST',{},code);assert.ok(premPaid.data.entitlements.premiumUntil>Date.now()+29*86400000);
 assert.equal((await request('entitlements','GET',undefined,code)).data.orders.filter(x=>x.status==='completed').length,4);
 assert.equal((await request('entitlements','GET',undefined,'nlg_'+ 'A'.repeat(43))).status,401);
 console.log('PASS: catálogo, precios, 5 selecciones, rechazo de duplicados, captura, acreditación, reintentos, recuperación y Premium.');
}catch(e){console.error('FAIL',e);process.exitCode=1}finally{child.kill('SIGTERM');rmSync(dir,{recursive:true,force:true});}
