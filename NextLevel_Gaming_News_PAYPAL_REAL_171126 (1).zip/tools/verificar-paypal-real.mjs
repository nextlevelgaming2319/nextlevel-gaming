const mode=process.env.PAYPAL_ENV==='live'?'live':'sandbox';
const id=process.env.PAYPAL_CLIENT_ID;
const secret=process.env.PAYPAL_CLIENT_SECRET;
if(!id||!secret){console.error('FALTAN PAYPAL_CLIENT_ID y/o PAYPAL_CLIENT_SECRET en las variables privadas del servidor.');process.exit(1)}
const api=mode==='live'?'https://api-m.paypal.com':'https://api-m.sandbox.paypal.com';
try{
 const response=await fetch(api+'/v1/oauth2/token',{method:'POST',headers:{Authorization:'Basic '+Buffer.from(id+':'+secret).toString('base64'),'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=client_credentials',signal:AbortSignal.timeout(12000)});
 const data=await response.json();
 if(!response.ok||!data.access_token)throw new Error('PayPal respondió HTTP '+response.status+' ('+(data.error||'autenticación rechazada')+')');
 console.log('CONEXIÓN REAL A PAYPAL: OK');
 console.log('Entorno:',mode==='live'?'PRODUCCIÓN (dinero real)':'SANDBOX (prueba oficial de PayPal)');
 console.log('Esto valida las credenciales, NO confirma que se haya completado una compra.');
}catch(error){console.error('NO SE PUDO CONECTAR CON PAYPAL:',error.message);process.exitCode=1}
